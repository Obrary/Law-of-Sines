Product: Law of Sines, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/law-of-sines

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a teaching tool designed to help a math teacher illustrate how in the law of sines, with a fixed angle a and length A, there can be two different angles b & c and sides B & C.